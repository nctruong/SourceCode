package com.java.basic.cover;

public abstract class Client {

	public Client(int id, String name, int age){}
	public abstract int getId();
	public abstract void setId(int id);
	public abstract String getName();
	public abstract void setName(String name);
	public abstract int getAge();
	public abstract void setAge(int age);

}
